import { Injectable } from '@angular/core';
import { Http ,Response} from '@angular/http';
import { Resource } from './resource';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class ResourceService {
//private apiUrl = ' http://localhost:8080/resources';
private apiUrl = 'https://global-management-application.herokuapp.com/resources';
constructor(private http: Http) { }
findAll(): Observable<Resource[]>  {
  return this.http.get(this.apiUrl)
    .map((res:Response) => res.json())
    .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
}
findById(id: number): Observable<Resource> {
  return this.http.get(this.apiUrl + '/' + id)
    .map((res:Response) => res.json())
    .catch((error:any) => Observable.throw(error.json().error || 'Error'));
}

save(model: Resource): Observable<Resource> {
  console.log("Saving "+model)
  return this.http.post(this.apiUrl, model)
  .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
}

deleteById(id: number): Observable<Response> {
  return this.http.delete(this.apiUrl + '/' + id)
  .map((res:Response) => res.json())
  .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
}

update(model: Resource): Observable<Resource> {
  return this.http.put(this.apiUrl, model)
    .map((res:Response) => res.json())
    .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
}

}
