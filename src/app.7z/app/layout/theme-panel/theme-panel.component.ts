import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-panel',
  templateUrl: './theme-panel.component.html',
  styleUrls: ['./theme-panel.component.css']
})
export class ThemePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
